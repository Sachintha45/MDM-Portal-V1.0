# MDM Portal — Seed Data (from Field_List_V1.xlsx)

Generated 28 Aug 2026. CSVs use the **physical deployed column names**
(matching `mdm_portal_*` tables), minus the auto-managed audit columns
(`createdAt`, `createdBy`, `modifiedAt`, `modifiedBy`).

**Policy: only data present in the Excel is populated. Invented/default values
have been removed and are listed below under "Must fill" / "Applied defaults".**

## Files → tables

| File | Table | Rows |
|---|---|---|
| MasterDataType.csv | mdm_portal_MasterDataType | 1 |
| FieldGroup.csv | mdm_portal_FieldGroup | 110 |
| ValueTable.csv | mdm_portal_ValueTable | 101 |
| FieldMaster.csv | mdm_portal_FieldMaster | 392 |
| BPRole.csv | mdm_portal_BPRole | 4 |
| BPRoleField.csv | mdm_portal_BPRoleField | 402 |
| GridColumn.csv | mdm_portal_GridColumn | 68 |

## FK column naming (CAP convention)

- `main_group_group_id` / `sub_group_group_id` → FieldGroup.group_id
- `master_data_type_master_data_type_id` → MasterDataType.master_data_type_id
- `value_table_value_table_id` → ValueTable.value_table_id
- `role_role_id` → BPRole.role_id
- `field_field_id` → FieldMaster.field_id
- `parent_group_id_group_id` → FieldGroup.group_id (self-ref)

## Source sheet → role mapping

| Excel sheet | role_id | description |
|---|---|---|
| General Data | GEN_DATA | General Data |
| Sales General | CUST_GEN | Customer General Data |
| Sales and Distribution | CUST_SLS | Customer Sales Data |
| Company Code | CUST_FI | Customer FI Data |
| Purchases | (folded into CUST_GEN) | duplicate subset of Sales General |

## ✅ Populated from Excel (real data)

- **FieldMaster**: field_id (field name), description, length, source_table
  (Excel "Value Table" column → the SAP structure), source_field, display_type
  (SEARCH_HELP when a search help exists), group assignments (main/sub),
  `grid` flag (from "MAIN GRID FIELD").
- **FieldGroup**: Main Group → Sub Group → Sub Group2 hierarchy (3 levels).
- **ValueTable**: `value_table_id` + `description` from the "Search Help
  Source" column (e.g. T005, SKB1, M_DEBIA).
- **BPRole / BPRoleField**: the 4 roles and their field assignments + sequence.
- **GridColumn**: grid columns from the "GRID FIELD" / "MAIN GRID FIELD" flags.

## 🧩 Applied defaults (low-risk system flags — change if needed)

| Field | Value | Reason |
|---|---|---|
| MasterDataType | CUSTOMER only | all data is customer BP data; VENDOR/MATERIAL not added |
| master_data_type | CUSTOMER | all roles/fields/groups are customer-scoped |
| account_scope | CUSTOMER | matches CDS default |
| active | true | all records start active |
| read_only | false | |
| initial_bp_required | false | |
| display_type | INPUT | for fields with no search help |

## ⚠️ Blank / MUST fill before insert

| Field | Blank count | Note |
|---|---|---|
| BPRoleField.field_status | 402 | set REQUIRED / OPTIONAL / SUPPRESS per field per role |
| FieldMaster.data_type | 246 | S&D + Company Code sheets had no types; back-filled where the same field had a type elsewhere, left blank otherwise |
| ValueTable.source_table | 101 | unknown |
| ValueTable.output_key | 101 | unknown |
| ValueTable.output_desc | 101 | unknown |
| ValueTable.status | 101 | set ACTIVE |
| FieldMaster.validation_validation_id | 392 | Excel "Validation" column was empty/`?` |
| BPRoleField.default_value | 402 | not in source |
| FieldMaster.decimals | 392 | not in source |

## Known data-quality issues (source Excel)

- Role/tab typos: "Shpping", "Documets", "Accounnt", "Trasnsaction", "Busines",
  "Refernce".
- Sheet2 (151 fields) is a stale partial list — not used.
- "Sales and Distribution" & "Company Code" have no Data Types.
- Some Search Help entries were "Data Element" annotations — cleaned best-effort.

## Loading

Load in FK order:
**MasterDataType → FieldGroup → ValueTable → FieldMaster → BPRole →
BPRoleField → GridColumn**.

Use `INSERT`/bulk load mapping headers to physical columns (HANA). For CAP
`db/data/` seed CSVs, rename files to `<namespace>-<Entity>.csv` and adapt FK
columns to logical element names.
